# ==========================================================
# 📘 InvestBot - Bot Discord d’analyse boursière éducatif
# ==========================================================
# Auteur : Emofal (2025)
# Droits d’auteur : © 2025 Emofal. Tous droits réservés.
# ----------------------------------------------------------
# Licence d’utilisation :
# Ce programme est fourni à titre éducatif et non commercial.
# Toute revente, diffusion ou modification non autorisée est interdite.
# ==========================================================
# Description :
# - Suivi automatique S&P500 + CAC40 → Top 20 titres (volatilité + rendement).
# - Paper trading : capital fixe 50 €, jamais en dessous ; vente uniquement si gain ≥ +3 %.
# - Tableau de bord Discord (Top 10, météo du marché, 3 actus) toutes les 2 h (épinglé).
# - Rapports journaliers EU/US (17:45 / 22:05, heure de Paris).
# - 100 % français, code structuré, commentaires professionnels.
# ==========================================================

import os, asyncio, sqlite3, time, json, re
from datetime import datetime
from statistics import mean
from collections import deque
import numpy as np
import pandas as pd
import yfinance as yf
import pytz
import aiohttp

import discord
from discord import app_commands
from discord.ext import tasks
from dotenv import load_dotenv

from keep_alive import keep_alive

# ----------------------------------------------------------
# Initialisation (Replit 24/7) + variables d’environnement
# ----------------------------------------------------------
keep_alive()
load_dotenv()
TOKEN_DISCORD = os.getenv("DISCORD_TOKEN")
ID_SALON_RAPPORT = int(os.getenv("REPORT_CHANNEL_ID", "0"))
DEVISE = os.getenv("FIAT", "EUR").upper()

PARIS_TZ = pytz.timezone("Europe/Paris")
DB = "paper.db"
FICHIER_TOP20 = "top20.json"
FICHIER_STATS = "stats.json"

# État runtime
WATCHLIST = {}             # {sym: deque(prix)}
METEO_MARCHE = "🌤️ Marché neutre"
ACTUS_JOUR = []            # 3 titres max
SEUIL_GAIN = 0.03          # +3%

# Intents Discord minimaux
intents = discord.Intents.default()
bot = discord.Client(intents=intents)
tree = app_commands.CommandTree(bot)

# ==========================================================
# Base de données (SQLite) – capital, positions
# ==========================================================
def db_init():
    con = sqlite3.connect(DB)
    cur = con.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS state(
        k TEXT PRIMARY KEY, v TEXT
    )""")
    cur.execute("INSERT OR IGNORE INTO state(k,v) VALUES('cash','50')")
    cur.execute("""CREATE TABLE IF NOT EXISTS positions(
        symbol TEXT PRIMARY KEY,
        ts INTEGER,
        entry REAL,
        size_eur REAL
    )""")
    con.commit(); con.close()

def lire_capital():
    con = sqlite3.connect(DB); cur = con.cursor()
    cur.execute("SELECT v FROM state WHERE k='cash'")
    row = cur.fetchone(); con.close()
    return float(row[0]) if row else 50.0

def ecrire_capital(nv):
    con = sqlite3.connect(DB); cur = con.cursor()
    cur.execute("INSERT OR REPLACE INTO state(k,v) VALUES('cash',?)", (str(nv),))
    con.commit(); con.close()

def ecrire_capital_securise(nv):
    """Empêche toute baisse du capital sous 50 €."""
    nv = max(50.0, float(nv))
    ecrire_capital(nv)

def get_position(sym):
    con = sqlite3.connect(DB); cur = con.cursor()
    cur.execute("SELECT symbol, ts, entry, size_eur FROM positions WHERE symbol=?", (sym,))
    row = cur.fetchone(); con.close()
    return row

def ouvrir_position(sym, entry, size_eur):
    con = sqlite3.connect(DB); cur = con.cursor()
    cur.execute("INSERT OR REPLACE INTO positions(symbol, ts, entry, size_eur) VALUES(?,?,?,?)",
                (sym, int(time.time()), entry, size_eur))
    con.commit(); con.close()

def fermer_position(sym):
    con = sqlite3.connect(DB); cur = con.cursor()
    cur.execute("DELETE FROM positions WHERE symbol=?", (sym,))
    con.commit(); con.close()

# ==========================================================
# Indicateurs simples
# ==========================================================
def sma(values, window):
    if len(values) < window: return None
    return float(mean(values[-window:]))

def rsi(values, period=14):
    if len(values) < period + 1: return None
    gains, losses = [], []
    for i in range(1, period+1):
        ch = values[-i] - values[-i-1]
        if ch >= 0: gains.append(ch)
        else: losses.append(-ch)
    avg_gain = sum(gains)/period if gains else 0.0
    avg_loss = sum(losses)/period if losses else 1e-9
    rs = avg_gain/avg_loss
    return float(100 - (100/(1+rs)))

# ==========================================================
# Construction de l’univers (S&P500 + CAC40) et Top20
# ==========================================================
def get_sp500():
    try:
        return yf.tickers_sp500()
    except Exception:
        return []

def get_cac40():
    try:
        tables = pd.read_html("https://fr.wikipedia.org/wiki/CAC_40")
        # On cherche la table avec une colonne 'Ticker' ou 'Code' etc.
        for t in tables:
            cols_lower = [str(c).lower() for c in t.columns]
            if any("ticker" in c or "code" in c for c in cols_lower):
                tickers = []
                for _, row in t.iterrows():
                    for c in t.columns:
                        if "Ticker" in str(c) or "Code" in str(c):
                            val = str(row[c]).strip()
                            if val and val != "nan":
                                tickers.append(val)
                            break
                # Ajout de Française des Jeux si manquante
                if "FDJ.PA" not in tickers:
                    tickers.append("FDJ.PA")
                return list(dict.fromkeys(tickers))
    except Exception:
        pass
    # Fallback
    return ["MC.PA","OR.PA","AIR.PA","AI.PA","BN.PA","BNP.PA","CA.PA","CAP.PA","CS.PA",
            "DG.PA","EL.PA","EN.PA","GLE.PA","KER.PA","LR.PA","RI.PA","SAF.PA","SAN.PA",
            "SU.PA","FDJ.PA"]

def zscore(a):
    a = np.array(a, dtype=float)
    return (a - np.nanmean(a)) / (np.nanstd(a) + 1e-9)

def classer_top20(univers):
    if not univers: return []
    data = yf.download(univers, period="1y", interval="1d", auto_adjust=True, threads=True, progress=False)
    if isinstance(data, pd.DataFrame) and ("Close" in data.columns):
        closes = data["Close"]
    else:
        closes = data

    ret6, vol60, syms = [], [], []
    for sym in univers:
        try:
            s = closes[sym].dropna()
            if len(s) < 90: 
                continue
            r6 = float(s.iloc[-1] / (s.iloc[-126] if len(s)>=126 else s.iloc[0]) - 1.0)
            rd = s.pct_change().dropna()
            v60 = float(rd.tail(60).std() * np.sqrt(252))
            if np.isnan(r6) or np.isnan(v60): 
                continue
            ret6.append(r6); vol60.append(v60); syms.append(sym)
        except Exception:
            continue
    if not syms: return []
    score = 0.6 * zscore(ret6) + 0.4 * zscore(vol60)
    df = pd.DataFrame({"symbol": syms, "ret6m": ret6, "vol60": vol60, "score": score})
    df = df[df["ret6m"] > 0].sort_values("score", ascending=False)
    return df.head(20)["symbol"].tolist()

def sauvegarder_top20(lst):
    with open(FICHIER_TOP20, "w", encoding="utf-8") as f:
        json.dump({"updated": datetime.utcnow().isoformat()+"Z", "symbols": lst}, f, ensure_ascii=False, indent=2)

def charger_top20():
    if not os.path.exists(FICHIER_TOP20): return []
    try:
        with open(FICHIER_TOP20, "r", encoding="utf-8") as f:
            return json.load(f).get("symbols", [])
    except Exception:
        return []

def reinitialiser_watchlist(symbols):
    global WATCHLIST
    WATCHLIST = {sym: deque(maxlen=200) for sym in symbols}

# ==========================================================
# Analyse d’actualités → météo du marché + 3 titres clés
# ==========================================================
MOTS_POS = ["hausse", "croissance", "rebond", "record", "bénéfice", "profit", "stabilité", "optimisme", "progression", "rallye"]
MOTS_NEG = ["chute", "baisse", "crise", "guerre", "tensions", "inflation", "faillite", "récession", "ralentissement", "krach"]

SOURCES_ACTUS = [
    "https://www.boursorama.com/breves/",
    "https://finance.yahoo.com/news/",
    "https://www.reuters.com/markets/"
]

async def analyser_actualites():
    """Récupère quelques pages d’actus et renvoie (meteo, titres_cles)."""
    textes, titres = [], []
    async with aiohttp.ClientSession() as session:
        for url in SOURCES_ACTUS:
            try:
                async with session.get(url, timeout=10) as r:
                    html = await r.text()
                    textes.append(html.lower())
                    # extraction naïve de titres <title> ou balises h2/h3
                    titres += re.findall(r"<title>([^<]{10,120})</title>", html, flags=re.I)
                    titres += re.findall(r"<h[23][^>]*>([^<]{10,120})</h[23]>", html, flags=re.I)
            except Exception:
                continue
    contenu = " ".join(textes)
    total = 0; score = 0
    for m in MOTS_POS:
        if m in contenu: score += 1; total += 1
    for m in MOTS_NEG:
        if m in contenu: score -= 1; total += 1
    indice = score / max(1, total)
    if indice > 0.1: meteo = "☀️ Marché haussier (confiance positive)"
    elif indice < -0.1: meteo = "🌧️ Marché baissier (sentiment négatif)"
    else: meteo = "🌤️ Marché neutre"
    # Nettoyage de 3 titres lisibles
    propres = []
    for t in titres:
        t2 = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", t)).strip()
        if 20 <= len(t2) <= 120 and t2 not in propres:
            propres.append(t2)
        if len(propres) >= 3: break
    return meteo, propres

# ==========================================================
# Logique SmartHold : achat/vente
# ==========================================================
def doit_acheter(sym):
    buf = WATCHLIST.get(sym)
    if not buf or len(buf) < 30:
        return False
    s9, s21 = sma(buf, 9), sma(buf, 21)
    rs = rsi(buf, 14)
    return (s9 is not None and s21 is not None and rs is not None and s9 > s21 and rs > 50)

def essayer_vendre(sym, prix_courant):
    pos = get_position(sym)
    if not pos: 
        return (False, 0.0)
    _, _, entree, taille = pos
    # Jamais de vente à perte : seulement si ≥ +3 %
    if prix_courant >= entree * (1.0 + SEUIL_GAIN):
        pnl = taille * ((prix_courant - entree) / entree)
        ecrire_capital_securise(lire_capital() + pnl)
        fermer_position(sym)
        return (True, pnl)
    return (False, 0.0)

# ==========================================================
# Tâches périodiques : marché, top20, dashboard, rapports
# ==========================================================
@tasks.loop(seconds=120)
async def boucle_marche():
    await bot.wait_until_ready()
    for sym in list(WATCHLIST.keys()):
        try:
            tk = yf.Ticker(sym)
            finfo = getattr(tk, "fast_info", None)
            prix = float(finfo.last_price) if finfo and finfo.last_price else None
            if prix is None:
                hist = tk.history(period="1d", interval="1m")
                if not hist.empty: prix = float(hist["Close"].iloc[-1])
            if not prix: 
                continue

            WATCHLIST[sym].append(prix)

            vendu, pnl = essayer_vendre(sym, prix)
            if vendu:
                print(f"[VENTE] {sym} @ {prix:.2f} | PnL +{pnl:.2f}€"); 
                continue

            if not get_position(sym) and doit_acheter(sym):
                cash = lire_capital()
                taille = min(2.0, cash * 0.05)  # taille minuscule adaptée à 50 €
                if taille >= 0.5:
                    ouvrir_position(sym, prix, taille)
                    print(f"[ACHAT] {sym} @ {prix:.2f} | taille {taille:.2f}€")
        except Exception:
            continue

@tasks.loop(hours=2)
async def dashboard_auto():
    await bot.wait_until_ready()
    ch = bot.get_channel(ID_SALON_RAPPORT)
    if not ch: return

    # Analyse des actus + mise à jour variables globales
    global METEO_MARCHE, ACTUS_JOUR
    try:
        METEO_MARCHE, ACTUS_JOUR = await analyser_actualites()
    except Exception:
        METEO_MARCHE, ACTUS_JOUR = "🌤️ Marché neutre", []

    message = generer_dashboard()
    msg = await ch.send(message)

    # Gestion des épingles : on ne garde que la plus récente du bot
    try:
        epingles = await ch.pins()
        for m in epingles:
            if m.author == bot.user:
                await m.unpin()
        await msg.pin()
    except Exception:
        pass

_last_eu = None; _last_us = None
@tasks.loop(seconds=60)
async def rapports_journaliers():
    await bot.wait_until_ready()
    ch = bot.get_channel(ID_SALON_RAPPORT)
    if not ch: return
    global _last_eu, _last_us
    now = datetime.now(PARIS_TZ).replace(second=0, microsecond=0)
    if now.hour == 17 and now.minute == 45 and _last_eu != now.date():
        await ch.send(await construire_rapport("EU", now)); _last_eu = now.date()
    if now.hour == 22 and now.minute == 5 and _last_us != now.date():
        await ch.send(await construire_rapport("US", now)); _last_us = now.date()

@tasks.loop(time=datetime.utcnow().replace(hour=6, minute=0, second=0, microsecond=0))
async def maj_top20():
    await bot.wait_until_ready()
    ch = bot.get_channel(ID_SALON_RAPPORT)
    try:
        univers = set(get_sp500()) | set(get_cac40())
        top20 = classer_top20(sorted([s for s in univers if s and not s.startswith("^")]))
        if top20:
            sauvegarder_top20(top20)
            reinitialiser_watchlist(top20)
            if ch:
                await ch.send("🔁 Watchlist mise à jour (Top 20) : " + ", ".join(top20))
    except Exception as e:
        if ch:
            await ch.send(f"⚠️ Échec mise à jour Top 20 : {e}")

# ==========================================================
# Tableau de bord + Rapports
# ==========================================================
def generer_dashboard():
    capital = lire_capital()
    base = 50.0
    gain = max(0.0, capital - base)
    rendement = (gain / base) * 100.0

    # Classement des positions ouvertes
    con = sqlite3.connect(DB); cur = con.cursor()
    cur.execute("SELECT symbol, entry, size_eur FROM positions")
    rows = cur.fetchall(); con.close()

    perfs = []
    for sym, entry, size in rows:
        last = WATCHLIST.get(sym, deque(maxlen=1))[-1] if sym in WATCHLIST and len(WATCHLIST[sym]) else entry
        var = (last/entry - 1.0) * 100.0
        perfs.append((sym, var))
    perfs.sort(key=lambda x: x[1], reverse=True)
    top10 = perfs[:10]

    lignes = [
        f"💹 **Tableau de bord InvestBot** – {datetime.now(PARIS_TZ).strftime('%d/%m %Hh%M')}",
        "",
        f"💰 **Capital total :** {capital:.2f} €",
        f"💶 **Capital investi :** {base:.2f} € (minimum garanti)",
        f"📈 **Gain cumulé :** +{gain:.2f} € ({rendement:.2f} %)",
        ""
    ]
    if top10:
        lignes.append("🏆 **Top 10 des positions actuelles :**")
        for i, (sym, v) in enumerate(top10, 1):
            pref = f"{i}️⃣" if i < 10 else "🔟"
            lignes.append(f"{pref} {sym} → {v:+.2f} %")
        lignes.append("")
    lignes.append(f"📰 **Météo du marché :** {METEO_MARCHE}")
    if ACTUS_JOUR:
        lignes.append("🗞️ **À retenir aujourd’hui :**")
        for t in ACTUS_JOUR[:3]:
            lignes.append(f"– {t}")
    lignes.append("")
    lignes.append("⏰ **Prochaine mise à jour :** dans 2 h")

    # Sauvegarde stats léger
    try:
        with open(FICHIER_STATS, "w", encoding="utf-8") as f:
            json.dump({"dernier_update": datetime.utcnow().isoformat()+"Z",
                       "capital": capital, "gain_total": gain, "rendement": rendement}, f, indent=2, ensure_ascii=False)
    except Exception:
        pass
    return "\n".join(lignes)

async def construire_rapport(tag, when_paris):
    lst = list(WATCHLIST.keys())
    lignes = [f"📊 **Rapport {tag} – {when_paris.strftime('%Y-%m-%d %H:%M')} (Paris)**\n"]
    for sym in lst:
        last = WATCHLIST[sym][-1] if len(WATCHLIST[sym]) else None
        if last is None: 
            continue
        first = WATCHLIST[sym][0] if len(WATCHLIST[sym]) else last
        delta = (last/first - 1.0) * 100.0 if first else 0.0
        pos = get_position(sym)
        status = "—"
        if pos:
            _, _, entry, size = pos
            status = f"🟢 pos @{entry:.2f} ({size:.2f}€)"
        lignes.append(f"• {sym}: {last:.2f} {DEVISE} ({delta:+.2f}%) {status}")
    lignes.append(f"\n💼 Solde fictif : **{lire_capital():.2f} €**")
    return "\n".join(lignes)

# ==========================================================
# Commandes Discord
# ==========================================================
@tree.command(name="dashboard", description="Affiche le tableau de bord instantané")
async def cmd_dashboard(interaction: discord.Interaction):
    # Mise à jour rapide de la météo/actus avant affichage manuel
    global METEO_MARCHE, ACTUS_JOUR
    try:
        METEO_MARCHE, ACTUS_JOUR = await analyser_actualites()
    except Exception:
        pass
    await interaction.response.send_message(generer_dashboard())

@tree.command(name="positions", description="Liste des positions ouvertes")
async def cmd_positions(interaction: discord.Interaction):
    con = sqlite3.connect(DB); cur = con.cursor()
    cur.execute("SELECT symbol, entry, size_eur FROM positions")
    rows = cur.fetchall(); con.close()
    if not rows:
        await interaction.response.send_message("Aucune position ouverte.")
        return
    lignes = ["Positions ouvertes :"]
    for sym, e, s in rows:
        last = WATCHLIST.get(sym, deque(maxlen=1))[-1] if sym in WATCHLIST and len(WATCHLIST[sym]) else e
        perf = (last/e - 1.0) * 100.0
        lignes.append(f"• {sym} @ {e:.2f} → {last:.2f} ({perf:+.2f}%) | {s:.2f}€")
    await interaction.response.send_message("\n".join(lignes))

@tree.command(name="cash", description="Affiche le solde fictif")
async def cmd_cash(interaction: discord.Interaction):
    await interaction.response.send_message(f"💰 Solde : {lire_capital():.2f} €")

@tree.command(name="watchlist", description="Affiche la watchlist Top 20 du jour")
async def cmd_watchlist(interaction: discord.Interaction):
    await interaction.response.send_message(", ".join(list(WATCHLIST.keys())) if WATCHLIST else "Watchlist vide (en attente de mise à jour).")

@tree.command(name="price", description="Prix instantanés des titres suivis")
async def cmd_price(interaction: discord.Interaction):
    msg = []
    for sym in WATCHLIST.keys():
        p = WATCHLIST[sym][-1] if len(WATCHLIST[sym]) else None
        if p is not None:
            msg.append(f"{sym}: {p:.2f} {DEVISE}")
    await interaction.response.send_message("\n".join(msg) if msg else "En attente de données…")

@tree.command(name="buy", description="Achat papier manuel (ex: /buy TSLA 1.0)")
async def cmd_buy(interaction: discord.Interaction, symbol: str, taille_eur: float = 1.0):
    sym = symbol.upper()
    if sym not in WATCHLIST:
        await interaction.response.send_message(f"{sym} n'est pas dans la watchlist du jour.")
        return
    if get_position(sym):
        await interaction.response.send_message(f"Déjà en position sur {sym}.")
        return
    last = WATCHLIST[sym][-1] if len(WATCHLIST[sym]) else None
    if not last:
        await interaction.response.send_message("Pas de prix disponible.")
        return
    taille = max(0.5, min(2.0, float(taille_eur)))
    ouvrir_position(sym, last, taille)
    await interaction.response.send_message(f"🟢 Achat {sym} @ {last:.2f} pour {taille:.2f}€ (papier)")

@tree.command(name="sell", description="Vente papier manuelle (respecte le seuil +3 %)")
async def cmd_sell(interaction: discord.Interaction, symbol: str):
    sym = symbol.upper()
    pos = get_position(sym)
    if not pos:
        await interaction.response.send_message("Aucune position.")
        return
    last = WATCHLIST[sym][-1] if sym in WATCHLIST and len(WATCHLIST[sym]) else None
    if not last:
        await interaction.response.send_message("Pas de prix.")
        return
    vendu, pnl = essayer_vendre(sym, last)
    if vendu:
        await interaction.response.send_message(f"✅ Vente {sym} @ {last:.2f} | PnL +{pnl:.2f}€")
    else:
        await interaction.response.send_message("🔒 Règle SmartHold : vente refusée (< +3%).")

# ==========================================================
# Démarrage du bot
# ==========================================================
@bot.event
async def on_ready():
    await tree.sync()
    # Watchlist initiale : charge Top20 sinon démarrage par défaut
    top20 = charger_top20()
    if not top20:
        # fallback minimal pour boot
        top20 = ["TSLA","NVDA","AAPL","MSFT","FDJ.PA","MC.PA","OR.PA","AI.PA","SU.PA","SAN.PA",
                 "AIR.PA","BNP.PA","CA.PA","DG.PA","EN.PA","KER.PA","RI.PA","LR.PA","GLE.PA","CAP.PA"]
        sauvegarder_top20(top20)
    reinitialiser_watchlist(top20)

    if not boucle_marche.is_running(): boucle_marche.start()
    if not maj_top20.is_running(): maj_top20.start()
    if not dashboard_auto.is_running(): dashboard_auto.start()
    if not rapports_journaliers.is_running(): rapports_journaliers.start()

    print(f"✅ Connecté comme {bot.user}")

bot.run(TOKEN_DISCORD)
