# 📘 InvestBot
_Bot Discord d’analyse boursière éducatif et automatisé – by **Emofal**_

**InvestBot** est un bot Discord francophone qui simule un portefeuille de **50 € fixes**.
Il observe le **S&P 500** et le **CAC 40**, sélectionne chaque jour les **20 titres les plus volatils et performants**, et publie toutes les **2 heures** un **tableau de bord épinglé** comprenant :
- un **Top 10 des positions** (perf %),
- la **météo du marché** (☀️ haussier / 🌤️ neutre / 🌧️ baissier),
- un **résumé des 3 actus économiques majeures** (titres).

> ⚠️ Usage **éducatif et personnel** uniquement. Aucune recommandation ou conseil d’investissement.

---

## 🚀 Installation rapide (Replit)
1. Créez un dépôt GitHub nommé **InvestBot** et uploadez ces fichiers, ou importez directement le ZIP fourni.
2. Dans Replit : **Create → Import from GitHub** → collez l’URL de votre dépôt.
3. Ouvrez l’onglet **Secrets (🔒)** et ajoutez :
   - `DISCORD_TOKEN` → Token de votre bot
   - `REPORT_CHANNEL_ID` → ID du salon Discord pour les rapports/dashboards
   - `FIAT` → `EUR` (par défaut)
4. Cliquez **Run ▶️**.

---

## 🔧 Fonctionnalités
- 💰 **Capital minimal garanti** : 50 € (ne descend jamais en dessous).
- 🧮 **Paper trading** : entrées simples (SMA9 > SMA21, RSI>50), ventes **uniquement** à partir de **+3 %**.
- 🔁 **Top 20 dynamique** : recalcul chaque matin (6 h, heure de Paris) sur S&P500 + CAC40.
- 📰 **Actualités & météo du marché** : analyse de titres FR/EN (Boursorama, Yahoo Finance, Reuters) → ☀️/🌤️/🌧️.
- 🏆 **Dashboard auto toutes les 2 h** : Top 10 positions, météo, « À retenir aujourd’hui ».
- 📌 **Épinglage automatique** : le dernier tableau de bord est toujours le seul message épinglé.
- 📊 **Rapports EU/US** : 17 h 45 (Europe) & 22 h 05 (États-Unis).

---

## 💬 Commandes Discord
- `/dashboard` → Affiche le tableau de bord instantané
- `/positions` → Liste des positions ouvertes
- `/cash` → Solde virtuel
- `/watchlist` → Watchlist Top 20 du jour
- `/price` → Prix instantanés des titres suivis
- `/buy` `/sell` → Achats/Ventes fictifs manuels (respect de la règle +3 %)

---

## 🧠 Notes techniques
- Données de marché via `yfinance` (Yahoo Finance). Pas de clé API requise.
- Actualités : scrapping léger (texte) via `aiohttp` (pas d’API payante nécessaire). Les sites d’actualité pouvant changer, l’analyse reste volontairement simple (mots-clés).
- Tous les textes, commentaires et logs sont en **français**.
- Style de code : PEP8, fonctions nommées clairement, commentaires structurés.

---

## ⚖️ Licence et protection
© 2025 **Emofal** – Tous droits réservés. Usage **éducatif et personnel** uniquement.  
Empreinte numérique (SHA1) : `1f5c03eb84e5a7c6b04aa2b30fc983b245b9d8ad`

Ce projet est **indépendant** et **non affilié** à Discord, Yahoo Finance, Boursorama, Reuters ou toute autre entité.

---

## 🧭 Roadmap (extraits)
- Filtre macro (inflation, PMI, chômage) dans la météo du marché
- Seuil de vente configurable (/set_threshold)
- Backtests intégrés (CSV) et rapport hebdo
